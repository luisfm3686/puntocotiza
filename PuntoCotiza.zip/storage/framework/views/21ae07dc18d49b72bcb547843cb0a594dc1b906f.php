<div class="sidebar">
    <nav class="sidebar-nav">
        <ul class="nav">
            <?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </ul>
    </nav>
    <button class="sidebar-minimizer brand-minimizer" type="button"></button>
</div>
<?php /**PATH C:\luisf\source\repos\PuntoCotiza\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>